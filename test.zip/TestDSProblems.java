/*
 Copyright (c) 2022 by ACI Worldwide, Inc.
 All rights reserved.
 
 This software is the confidential and proprietary information
 of ACI Worldwide Inc ("Confidential Information").  You shall
 not disclose such Confidential Information and shall use it
 only in accordance with the terms of the license agreement
 you entered with ACI Worldwide Inc.
 */

package test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * TODO
 *
 */
public class TestDSProblems
{
	static void swapArray(int [] array, int a , int b)
	{
		int temp = array[b];
		array[b] = array[a];
		array[a] = temp;
	}
	static void convertToWavePattern1(int [] nums)
	{
		System.out.println("Array before sorting ="+ Arrays.toString(nums));
		Arrays.sort(nums);
		System.out.println("Array after sorting ="+ Arrays.toString(nums));
		for (int i=1;i < nums.length-1; i=i+2)
		{
			swapArray(nums,i,i+1);	
		}
		System.out.println("Array wave patter ="+ Arrays.toString(nums));
	}
	
	static void convertToWavePattern2(int [] nums)
	{
		System.out.println("Array before sorting ="+ Arrays.toString(nums));
		
		//Evens have to be higher than the odds
		for (int i=0;i < nums.length-1; i=i+2)
		{
			System.out.println(i);
			//Current even is smaller that the previous 
			if(i>0 && nums[i] < nums[i-1])
			{
				swapArray(nums,i,i-1);
			}
			
			//Current even is smaller that the next 
			if( i < nums.length-2 && nums[i] < nums[i+1])
			{
				swapArray(nums,i,i+1);
			}
		}
		
		System.out.println("Array wave patter ="+ Arrays.toString(nums));
	}
	
	public static boolean areEqual(int [] a , int [] b)
	{
		int n = a.length;
		int m = b.length;
		if(n != m)
		{
			return false;
		}
		
		Map <Integer,Integer> hm = new HashMap <Integer,Integer> ();
		
		for(int c: a)
		{
			Integer count = hm.get(c);
			
			if(count == null)
			{
				hm.put(c,1);
			}
			else
			{
				hm.put(c, count+1);
			}
		}
		
		for (int c: b)
		{
			Integer count = hm.get(c);
			
			// a does not have it
			if(count == null)
			{
				return false;
			}
			else
			{
				// b has more of it than a
				if(count == 0)
				{
					return false;
				}
				
				hm.put(c,count-1);
			}
		}
		
		return true;
	}
	
	public static void mergeArray(int [] a, int [] b)
	{
		int n = a.length;
		int m = b.length;
		int i=0; int j=0; int k=0;
		int [] c = new int [m+n];
		
		System.out.println("Going to  merge a: "  + Arrays.toString(a));
		System.out.println("Going to  merge b: "  + Arrays.toString(b));
		
		while(i < n && j < m)
		{
			if(a[i] < b[j])
			{
				c[k++] = a[i++];
			}
			else
			{
				c[k++] = b[j++];
			}
		}
		
		while(i<n)
		{
			c[k++] = a[i++];
		}
		
		while(j<m)
		{
			c[k++] = b[j++];
		}
		
		System.out.println("After merge :"  + Arrays.toString(c));
	}
	
	/* Merge one sorted array of n size into another sorted array of m+n size*/
	//Does not work TBD
	public static void mergeIntoArray(int [] a, int [] b)
	{
		int n = a.length -1;
		int m = b.length -1;
		int i=n; int j = 0; int k=n;
				
		System.out.println("Going to  merge a: "  + Arrays.toString(a));
		System.out.println("Going to  merge b: "  + Arrays.toString(b));
		
		while(k > -1)
		{
			System.out.println("k =="+ k + "  "+a[k]);
			if(a[k] != 0)
			{
				if(i != k)
				{
					a[i--] = a[k];
					a[k] = 0;
				}
				else
				{
					i--;
				}
			}
			k--;
		}
	
		k = 0;
			
		System.out.println("Going to  merge a: "  + Arrays.toString(a));
		
		while(i < n && j < m)
		{
			if(a[i] < b[j])
			{
				a[k++] = a[i++];
			}
			else
			{
				a[k++] = b[j++];
			}
		}
		
		System.out.println(" " + i + j + k);
		while(i<=n)
		{
			a[k++] = a[i++];
		}
		
		while(j<m)
		{
			a[k++] = b[j++];
		}
		
		System.out.println("After merge :"  + Arrays.toString(a));
	}
	
	
// function for sort array
   static void sortit(int []arr, int n)
   {
   	 System.out.println("Before sort :"  + Arrays.toString(arr));
       for (int i = 0; i < n; i++)
       {
           arr[i]=i+1;
        }
       
       System.out.println("After sort :"  + Arrays.toString(arr));
   }
   
	public static void main(String args[])
	{
		int [] nums = {5,2,3,1,6,7};
		//convertToWavePattern1(nums);
		//convertToWavePattern2(nums);
		
		 //int arr1[] = { 3, 5, 2, 5, 2 };
       //int arr2[] = { 2, 3, 5, 5, 2 };
       int arr1[] = { 2,5,5,5,4};
       int arr2[] = { 2,5,5,5,2};
       

       if (areEqual(arr1, arr2))
           System.out.println("Yes");
       else
           System.out.println("No");
       
       
       int arr3[] = { 1,3,8};
       int arr4[] = { 2,5,20};
       
       mergeArray(arr3,arr4);
       
       int arr5[] = new int [6];
       arr5[0]= 1;
       arr5[3]= 3;
       arr5[5]= 8;
                 
       mergeIntoArray(arr5,arr4);
       
       sortit(nums, nums.length);
	}
}

