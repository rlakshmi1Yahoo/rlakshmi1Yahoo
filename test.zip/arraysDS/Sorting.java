/*
 Copyright (c) 2022 by ACI Worldwide, Inc.
 All rights reserved.
 
 This software is the confidential and proprietary information
 of ACI Worldwide Inc ("Confidential Information").  You shall
 not disclose such Confidential Information and shall use it
 only in accordance with the terms of the license agreement
 you entered with ACI Worldwide Inc.
 */

package test.arraysDS;

import java.util.Arrays;

/**
 * TODO
 *
 */
public class Sorting
{
	
	static int partition(int [] args, int low , int high)
	{
		int pivot = args [high];
		int j = 0;
		int i = 0;
		int temp = 0;
		
		for(i=0; i < high; i++)
		{
			if(args[i] < pivot)
			{
				temp = args[j];
				args[j]= args[i];
				args[i] = temp;
				//pointer to the low number
				j++;
			}
		}
		
		//Bring pivot to the correct place
		temp = args[j];
		args[j] = args[i];
		args[i] = temp;
		
		return j;
	}
	
	static int [] merge(int [] a , int [] b)
	{
		int i=0;
		int j=0;
		int k =0;
		int n = a.length;
		int m = b.length;
		int [] c = new int [m+n];
				
		while (i < m || j <n)
		{
			if(a[i] < b[j])
			{
				c[k++] = a[i++];
			}
			else
			{
				c[k++] = b[j++];
			}
		}
		
		while(i < m)
		{
			c[k++] = a[i++];
		}
		
		while(j < n)
		{
			c[k++] = b[j++];
		}
		
		return c;
	}
	
	static void quickSort(int [] args , int low, int high)
	{
		if(low < high)
		{
			int pi = partition (args, low, high);
			//System.out.println("After partition"+ Arrays.toString(args));
			//System.out.println("pi =="+ pi);
			quickSort(args,low,pi-1);
			quickSort(args,pi+1,high);
		}
	}
	
	
	static int [] mergeSort(int [] args , int length)
	{
		if(length > 0)
		{
			return merge( mergeSort(args,length/2) ,mergeSort(args,length/2+1));
		}
	}

	public static void main (String args[])
	{
		//int nums [] = {10,80,40,50,30,90,70};
		int nums1 [] = {80,70,40,50,30,90,10};
		
		System.out.println("Before Quick sort"+ Arrays.toString(nums1));
		quickSort(nums1, 0 , nums1.length-1);
		System.out.println("After Quick sort"+ Arrays.toString(nums1));
		
		int nums2 [] = {80,70,40,50,30,90,10};
		
		System.out.println("Before Quick sort"+ Arrays.toString(nums2));
		mergeSort(nums2, nums2.length-1);
		System.out.println("After Quick sort"+ Arrays.toString(nums2));
	}
}

