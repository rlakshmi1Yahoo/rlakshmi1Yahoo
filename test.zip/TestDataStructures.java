package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

import edu.emory.mathcs.backport.java.util.Collections;

public class TestDataStructures{
	
	enum days {  
		  SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY  
		};
		
	public void testDataStructures()
	{
		System.out.println("About to test array of ints");
		//int [] nums = new int [5];
		int [] nums = {1,2,3,-1,0};
		for(int i : nums)
		{
			System.out.println(i);
		}
		
		Arrays.sort(nums);
		System.out.println("Sort the array ="+ Arrays.toString(nums));
		
		
		System.out.println("About to test array of chars");
		char [] chars = {'1','2','3','4','5'};
		for(char i : chars)
		{
			System.out.println(i);
		}
		
		System.out.println("About to test array of Strings");
		String [] strs = {"1","2","3","4","5"};
		for(String i : strs)
		{
			System.out.println(i);
		}
		
		System.out.println("About to test Arraylist of Strings");
		ArrayList<String> strs_list = new ArrayList<String>();
		strs_list.add("1");
		strs_list.add("2");
		strs_list.add("3");
		
		for(String i: strs_list)
		{
			System.out.println(i);
		}
		
		System.out.println("About to test Arraylist of Integers");
		ArrayList<Integer> nums_list = new ArrayList<Integer>();
		nums_list.add(1);
		nums_list.add(2);
		nums_list.add(3);
		nums_list.set(1,4);
		for(Integer i: nums_list)
		{
			System.out.println(i);
		}
		
		System.out.println("nums_list ="+ nums_list);
		
		System.out.println("About to test Arraylist of Integers via Iterator");
		
		Iterator<Integer> iter = nums_list.iterator();
		while(iter.hasNext())
		{
			System.out.println(iter.next());
		}
		
		System.out.println("About to test Linkedlist of Integers via Iterator");
		LinkedList<Integer> nums_llist = new LinkedList<Integer> ();
		nums_llist.add(4);
		nums_llist.add(5);
		nums_llist.add(6);
	
		System.out.println("nums_llist ="+ nums_llist);
		
		iter = nums_llist.iterator();
		
		while (iter.hasNext())
		{
			System.out.println(iter.next());
		}
		
		System.out.println("About to test Linkedlist of Strings via Iterator");
		LinkedList<String> strs_llist = new LinkedList<String> ();
		strs_llist.add("4");
		strs_llist.add("5");
		strs_llist.add("6");
		strs_llist.set(1,"6");
		System.out.println("strs_llist ="+ strs_llist);
		
		Iterator<String> str_iter = strs_llist.iterator();
		
		while (str_iter.hasNext())
		{
			System.out.println(str_iter.next());
		}
		
		System.out.println("About to test convert list to array");
		String [] str_array = strs_llist.toArray(new String [strs_llist.size()]);
		System.out.println("str_array"+ Arrays.toString(str_array));
		
		System.out.println("About to test Vector of Strings");
		
		Vector <String> str_vector = new Vector <String> ();
		str_vector.add("1");
		str_vector.add("2");
		str_vector.add("3");
		str_vector.add(1,"4");
		for(String i : str_vector)
		{
			System.out.println("via for each "+i);
		}
		
		str_iter = str_vector.iterator();
		while(str_iter.hasNext())
		{
			System.out.println("via iter "+ str_iter.next());
		}
		
		Stack <String> str_stack = new Stack <String>();
		str_stack.push("1");
		str_stack.push("2");
		
		System.out.println("Stack:"+ str_stack);
		System.out.println("Stack peek ="+ str_stack.peek());
		System.out.println("Stack pop = "+ str_stack.pop());
		System.out.println("Stack:"+ str_stack);
		System.out.println("Stack peek = "+ str_stack.peek());
		
		PriorityQueue<String> queue=new PriorityQueue<String>();  
		queue.add("1");
		queue.offer("2");
		System.out.println("Queue before:"+ queue);
		System.out.println("Queue Element:"+ queue.element());
		System.out.println("Queue peek :"+ queue.peek());
		System.out.println("Queue remove:"+ queue.remove());
		System.out.println("Queue remove:"+ queue.poll());		
		System.out.println("Queue after:"+ queue);
		
		System.out.println("Testing Maps");
		
		Map <Integer,String> str_map = new HashMap<Integer,String>();
		str_map.put(1,"One");
		str_map.put(3,"Three");
		str_map.put(2,"Two");
		Set set = str_map.entrySet();
		Iterator set_iter = set.iterator();
		
		System.out.println("Old EntrySet iterator version");
		while(set_iter.hasNext())
		{
			Map.Entry e = (Map.Entry)set_iter.next();
			System.out.println(e.getKey() +" : "+ e.getValue() );
		}
	
		System.out.println("new For using EntrySet version");
		for(Map.Entry e : str_map.entrySet())
		{
			System.out.println(e.getKey() +" : "+ e.getValue() );
		}
		
		System.out.println("old KeySet version");
		
		set = str_map.keySet();
		set_iter = set.iterator();
		while(set_iter.hasNext())
		{
			Integer e = (Integer)set_iter.next();
			System.out.println(e +" : "+ str_map.get(e) );
		}
		
		System.out.println("Testing Steam comparing and for each");
		str_map.entrySet().stream().
		sorted(Map.Entry.comparingByKey()).
		forEach(System.out::println);
		
		System.out.println("Testing Steam comparing and for each using Lambada");
		
		str_map.forEach((key,value)->
			{
				System.out.println("key=="+ key); 
				System.out.println("value=="+ value);
			});
		
		System.out.println("Testing Stream comparing by value");
		str_map.entrySet().stream().
		sorted(Map.Entry.comparingByValue()).
		forEach(System.out::println);
		
		
		System.out.println("Testing Stream comparing by value");
		str_map.entrySet().stream().
		sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).
		forEach(System.out::println);
		
		System.out.println("Testing String keys in hash map method interface");
		Map <String,String> str_map_1 = new HashMap<String,String>();
		str_map_1.put("O","One");
		str_map_1.put("H","Three");
		str_map_1.put("W","Two");
		
		str_map_1.entrySet().stream().
		sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).
		forEach(System.out::println);
		
		System.out.println("Testing Hashtable");
		
		System.out.println("Testing Hashtable foreach lambada");
		Hashtable <Integer,String> str_ht = new Hashtable <Integer,String> ();
		str_ht.put(1,"one");
		str_ht.put(2,"two");
		str_ht.put(3,"three");
		str_ht.forEach((key,value)->
		{
			System.out.println(key +":"+ value);
		});
		
		System.out.println("Testing Hashtable for loop");
		
		for(Map.Entry c: str_ht.entrySet())
		{
			System.out.println(c.getKey() +":"+ c.getValue());
		}
		
		System.out.println("Testing Hashtable iterator loop key set");
		
		Iterator <Integer> ht_iter = str_ht.keySet().iterator();
		while(ht_iter.hasNext())
		{
			Integer key = ht_iter.next();
			System.out.println(key+"=="+ str_ht.get(key));
		}
		
		System.out.println("Testing Hashtable iterator loop entry set");
		
		Iterator <Map.Entry<Integer, String>> ht_iter_1 = str_ht.entrySet().iterator();
		while(ht_iter_1.hasNext())
		{
			
			System.out.println(ht_iter_1.next().getKey());
		}
		
		System.out.println("Testing Hashtable enumeration loop entry set");
		Enumeration <String> str_enum = str_ht.elements();
		while(str_enum.hasMoreElements())
		{
			System.out.println(str_enum.nextElement());
		}
		
		Enumeration <Integer> strk_enum = str_ht.keys();
		while(strk_enum.hasMoreElements())
		{
			System.out.println(strk_enum.nextElement());
		}
		
		Set enum_set = EnumSet.of(days.MONDAY,days.FRIDAY); 
		System.out.println(enum_set);
		
		System.out.println("Test sorting via Comparable");
		
		ArrayList<Student> student_array = new ArrayList <Student>();
	  	student_array.add(new Student(1,"Bala",60));
	  	student_array.add(new Student(2,"Savitha",50));
	  	student_array.add(new Student(3,"Lakshmi",45));
	  	
	  	System.out.println ("Before sorting:"+ student_array);
	  	Collections.sort(student_array);
	  	System.out.println ("After sorting:"+ student_array);
	  	
	  	System.out.println("Test sorting via Comparator");
		
		System.out.println ("Before sorting by age:"+ student_array);
	  	Collections.sort(student_array,new AgeComparator());
	  	System.out.println ("After sorting by age:"+ student_array);
	  	
	  	
	  	System.out.println("Test sorting via name using lambada expression");
	  	System.out.println ("Before sorting by age:"+ student_array);
	  	Comparator<Student> cm1=Comparator.comparing(Student::getName);  
	   Collections.sort(student_array,cm1);
	  	System.out.println ("After sorting by age:"+ student_array);
	}
	
	public class Student implements Comparable <Student>
	{
		 int rollno;    
		 String name;    
		 int age;    
		 
		 Student(int rollno,String name,int age){    
		 this.rollno=rollno;    
		 this.name=name;    
		 this.age=age;    
		 }

		 String getName()
		 {
			 return name;
		 }
		/**
		 * TODO
		 *
		 * @param arg0
		 * @return
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		@Override
		public int compareTo(Student arg0)
		{
			if (rollno > arg0.rollno )
			{
				return 1;
			}
			else if(rollno < arg0.rollno)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}    
		
		public String toString()
		{
			return (this.rollno+":"+ this.name +":"+ this.age);
		}
	}
	
	public class AgeComparator implements Comparator <Student>{

		/**
		 * TODO
		 *
		 * @param arg0
		 * @param arg1
		 * @return
		 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
		 */
		@Override
		public int compare(Student s1, Student s2)
		{
			if (s1.age > s2.age )
			{
				return 1;
			}
			else if(s1.age < s2.age)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
	}
	public static void main (String [] args)
	{
		TestDataStructures t = new TestDataStructures();
		t.testDataStructures();
	}
		
}
